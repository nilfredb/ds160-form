import { motion } from 'framer-motion';
import { MapPinIcon, PhoneIcon, EnvelopeIcon } from '@heroicons/react/24/solid';

export default function Contact() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="container mx-auto px-4 py-20"
    >
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-3xl font-bold text-blue-900 mb-8">Contacto</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="flex items-center">
              <MapPinIcon className="h-8 w-8 text-blue-600 mr-4" />
              <div>
                <h3 className="text-lg font-semibold">Oficina Principal</h3>
                <p className="text-gray-600">Av. Principal 123, Miami, FL</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <PhoneIcon className="h-8 w-8 text-blue-600 mr-4" />
              <div>
                <h3 className="text-lg font-semibold">Teléfono</h3>
                <p className="text-gray-600">+1 (829) 929-5562</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <EnvelopeIcon className="h-8 w-8 text-blue-600 mr-4" />
              <div>
                <h3 className="text-lg font-semibold">Correo Electrónico</h3>
                <p className="text-gray-600">contacto@visalegal.com</p>
              </div>
            </div>
          </div>

          <form className="space-y-4">
            <input
              type="text"
              placeholder="Nombre completo"
              className="w-full p-3 border rounded-lg"
            />
            <input
              type="email" 
              placeholder="Correo electrónico"
              className="w-full p-3 border rounded-lg"
            />
            <textarea
              placeholder="Mensaje"
              rows="4"
              className="w-full p-3 border rounded-lg"
            ></textarea>
            <button className="bg-blue-900 text-white px-6 py-3 rounded-lg w-full hover:bg-blue-800 transition-colors">
              Enviar Mensaje
            </button>
          </form>
        </div>
      </div>
    </motion.div>
  );
}