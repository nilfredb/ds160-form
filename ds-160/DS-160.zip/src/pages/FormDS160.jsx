// src/pages/FormDS160.js
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm, useFieldArray } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

import ProgressBar from '../components/ProgressBar';
import DynamicField from '../components/ui/DynamicField';
import { ds160Questions } from '../data/ds160Questions';
import Disclaimer from '../components/Disclaimer';

/////////////////////////////////////////////////
// Definimos campos “extras” que se mostrarán
// sólo si la condición lo amerita.
/////////////////////////////////////////////////
const extraFields = {
  otherNamesDetail: {
    type: 'text',
    name: 'otherNamesDetail',
    label: 'Indique el apodo u otro nombre que ha usado'
  },
  lostPassportExplanation: {
    type: 'text',
    name: 'lostPassportExplanation',
    label: 'Explique en detalle sobre el pasaporte perdido o robado'
  },
  tripSponsorName: {
    type: 'text',
    name: 'tripSponsorName',
    label: 'Nombre de la persona que patrocina su viaje'
  },
  tripSponsorLastName: {
    type: 'text',
    name: 'tripSponsorLastName',
    label: 'Apellido de la persona que patrocina su viaje'
  },
  tripSponsorAddress: {
    type: 'text',
    name: 'tripSponsorAddress',
    label: 'Dirección del patrocinador'
  },
  tripSponsorEmail: {
    type: 'email',
    name: 'tripSponsorEmail',
    label: 'Correo electrónico (opcional)'
  },
  tripSponsorRelationship: {
    type: 'text',
    name: 'tripSponsorRelationship',
    label: 'Relación/parentesco con el patrocinador'
  }
};

/////////////////////////////////////////////////
// Generamos el esquema Yup con validaciones
// condicionales en base a los “watchers”.
/////////////////////////////////////////////////
const generateValidationSchema = () => {
  // Esquema base de ds160Questions
  const schemaShape = {};

  ds160Questions.forEach((section) => {
    section.fields.forEach((field) => {
      if (field.required) {
        schemaShape[field.name] = yup
          .string()
          .required('Este campo es obligatorio');
      }
    });
  });

  // Validaciones condicionales
  return yup.object().shape({
    ...schemaShape,

    // Si otherNamesUsed === "Sí" => otherNamesDetail es requerido
    otherNamesDetail: yup
      .string()
      .when('otherNamesUsed', {
        is: (val) => val === 'Sí',
        then: (schema) => schema.required('Por favor indique el otro nombre'),
        otherwise: (schema) => schema.notRequired()
      }),

    // Si lostPassport === "Sí" => lostPassportExplanation es requerido
    lostPassportExplanation: yup
      .string()
      .when('lostPassport', {
        is: (val) => val === 'Sí',
        then: (schema) =>
          schema.required('Explique el pasaporte perdido o robado'),
        otherwise: (schema) => schema.notRequired()
      }),

    // Si payOwnTrip === "No" => se requieren los datos del patrocinador
    tripSponsorName: yup
      .string()
      .when('payOwnTrip', {
        is: (val) => val === 'No',
        then: (schema) =>
          schema.required('Ingrese el nombre del patrocinador'),
        otherwise: (schema) => schema.notRequired()
      }),
    tripSponsorLastName: yup
      .string()
      .when('payOwnTrip', {
        is: (val) => val === 'No',
        then: (schema) =>
          schema.required('Ingrese el apellido del patrocinador'),
        otherwise: (schema) => schema.notRequired()
      }),
    tripSponsorAddress: yup
      .string()
      .when('payOwnTrip', {
        is: (val) => val === 'No',
        then: (schema) => schema.required('Ingrese la dirección del patrocinador'),
        otherwise: (schema) => schema.notRequired()
      }),
    tripSponsorEmail: yup
      .string()
      .email('Correo inválido')
      .notRequired(), // Opcional en todos los casos
    tripSponsorRelationship: yup
      .string()
      .when('payOwnTrip', {
        is: (val) => val === 'No',
        then: (schema) =>
          schema.required('Ingrese la relación con el patrocinador'),
        otherwise: (schema) => schema.notRequired()
      }),

    // employerName y employmentStartDate sólo requeridos si
    // currentOccupation != 'Desempleado'
    employerName: yup
      .string()
      .when('currentOccupation', {
        is: (val) => val && val.toLowerCase() !== 'desempleado',
        then: (schema) => schema.required('Ingrese el nombre de su empleador'),
        otherwise: (schema) => schema.notRequired()
      }),
    employmentStartDate: yup
      .date()
      .typeError('Ingrese una fecha válida (AAAA-MM-DD)')
      .when('currentOccupation', {
        is: (val) => val && val.toLowerCase() !== 'desempleado',
        then: (schema) => schema.required('Ingrese la fecha de inicio'),
        otherwise: (schema) => schema.notRequired()
      }),

    // Familiares en EE.UU. (usRelativesList) si es "Sí"
    usRelativesList: yup.array().of(
      yup.object().shape({
        fullName: yup.string().required('Indique el nombre completo'),
        relationship: yup.string().required('Indique el parentesco')
      })
    )
  });
};

export default function FormDS160() {
  //////////////////////////////////////////////////
  // useState para controlar pasos (secciones)
  //////////////////////////////////////////////////
  const [currentStep, setCurrentStep] = useState(0);
  const totalSteps = ds160Questions.length;

  //////////////////////////////////////////////////
  // useForm con Yup
  //////////////////////////////////////////////////
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    trigger,
    control
  } = useForm({
    resolver: yupResolver(generateValidationSchema()),
    defaultValues: {
      // Inicializamos la lista de familiares
      usRelativesList: [{ fullName: '', relationship: '' }]
    }
  });

  //////////////////////////////////////////////////
  // Manejo de listas dinámicas
  //////////////////////////////////////////////////
  const { fields: relativesFields, append, remove } = useFieldArray({
    control,
    name: 'usRelativesList'
  });

  //////////////////////////////////////////////////
  // Watchers para preguntas “trigger”
  //////////////////////////////////////////////////
  const watchOtherNamesUsed = watch('otherNamesUsed');       // Sección Información Básica
  const watchLostPassport = watch('lostPassport');           // Sección Detalles del Pasaporte
  const watchPayOwnTrip = watch('payOwnTrip');               // Sección Planes de Viaje
  const watchUSRelatives = watch('usRelatives');             // Sección Información Familiar
  // (Más watchers si necesitas)

  //////////////////////////////////////////////////
  // Manejo de pasos
  //////////////////////////////////////////////////
  const handleNext = async () => {
    // Obtenemos los campos requeridos en la sección actual
    const requiredFields = ds160Questions[currentStep].fields
      .filter((field) => field.required)
      .map((field) => field.name);

    // Validar sólo esos campos
    const isValid = await trigger(requiredFields);
    if (isValid && currentStep < totalSteps - 1) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  };

  //////////////////////////////////////////////////
  // onSubmit final
  //////////////////////////////////////////////////
  const onSubmit = (data) => {
    console.log('Form Data:', data);
    // Aquí podrías hacer la llamada a tu API o
    // manejar la lógica de envío
  };

  //////////////////////////////////////////////////
  // Render
  //////////////////////////////////////////////////
  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-lg">
      {/* Barra de progreso (opcional) */}
      <ProgressBar step={currentStep + 1} totalSteps={totalSteps} />

      {/* Disclaimer o aviso (opcional) */}
      <Disclaimer />

      <form onSubmit={handleSubmit(onSubmit)}>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="space-y-6"
          >
            <h2 className="text-2xl font-semibold text-blue-900 mb-6">
              {ds160Questions[currentStep].section}
            </h2>

            {/* Mapeamos los campos de la sección actual */}
            {ds160Questions[currentStep].fields.map((field, index) => (
              <div key={index}>
                {/* Campo principal */}
                <DynamicField
                  fieldConfig={field}
                  register={register}
                  errors={errors}
                />

                {/* CONDICIONALES just below the trigger field */}

                {/* 1. Si el campo es "otherNamesUsed" y la respuesta es "Sí"... */}
                {field.name === 'otherNamesUsed' && watchOtherNamesUsed === 'Sí' && (
                  <DynamicField
                    fieldConfig={extraFields.otherNamesDetail}
                    register={register}
                    errors={errors}
                  />
                )}

                {/* 2. Si el campo es "lostPassport" y la respuesta es "Sí"... */}
                {field.name === 'lostPassport' && watchLostPassport === 'Sí' && (
                  <DynamicField
                    fieldConfig={extraFields.lostPassportExplanation}
                    register={register}
                    errors={errors}
                  />
                )}

                {/* 3. Si el campo es "payOwnTrip" y la respuesta es "No"... */}
                {field.name === 'payOwnTrip' && watchPayOwnTrip === 'No' && (
                  <>
                    <DynamicField
                      fieldConfig={extraFields.tripSponsorName}
                      register={register}
                      errors={errors}
                    />
                    <DynamicField
                      fieldConfig={extraFields.tripSponsorLastName}
                      register={register}
                      errors={errors}
                    />
                    <DynamicField
                      fieldConfig={extraFields.tripSponsorAddress}
                      register={register}
                      errors={errors}
                    />
                    <DynamicField
                      fieldConfig={extraFields.tripSponsorEmail}
                      register={register}
                      errors={errors}
                    />
                    <DynamicField
                      fieldConfig={extraFields.tripSponsorRelationship}
                      register={register}
                      errors={errors}
                    />
                  </>
                )}

                {/* 4. Si el campo es "usRelatives" y la respuesta es "Sí" => lista dinámica */}
                {field.name === 'usRelatives' && watchUSRelatives === 'Sí' && (
                  <div className="bg-gray-50 p-4 rounded-md mt-2">
                    <h3 className="font-semibold mb-2">
                      Información de los familiares en EE.UU.
                    </h3>
                    {relativesFields.map((relField, i) => (
                      <div key={relField.id} className="mb-4 border-b pb-2">
                        <label className="block text-gray-700 mb-1">
                          Nombre completo del familiar
                        </label>
                        <input
                          type="text"
                          {...register(`usRelativesList.${i}.fullName`)}
                          className={`w-full p-2 border ${
                            errors.usRelativesList?.[i]?.fullName
                              ? 'border-red-500'
                              : 'border-gray-300'
                          } rounded-md mb-2`}
                        />
                        {errors.usRelativesList?.[i]?.fullName && (
                          <span className="text-red-500 text-sm">
                            {errors.usRelativesList[i].fullName.message}
                          </span>
                        )}

                        <label className="block text-gray-700 mb-1">
                          Parentesco
                        </label>
                        <input
                          type="text"
                          {...register(`usRelativesList.${i}.relationship`)}
                          className={`w-full p-2 border ${
                            errors.usRelativesList?.[i]?.relationship
                              ? 'border-red-500'
                              : 'border-gray-300'
                          } rounded-md`}
                        />
                        {errors.usRelativesList?.[i]?.relationship && (
                          <span className="text-red-500 text-sm">
                            {errors.usRelativesList[i].relationship.message}
                          </span>
                        )}

                        <button
                          type="button"
                          className="text-sm text-red-500 mt-2"
                          onClick={() => remove(i)}
                        >
                          Eliminar este familiar
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      className="bg-blue-700 text-white px-4 py-2 rounded-md"
                      onClick={() => append({ fullName: '', relationship: '' })}
                    >
                      Agregar otro familiar
                    </button>
                  </div>
                )}
              </div>
            ))}

            {/* Botones de navegación */}
            <div className="flex justify-between mt-8">
              {currentStep > 0 && (
                <motion.button
                  type="button"
                  onClick={handlePrev}
                  whileHover={{ scale: 1.05 }}
                  className="bg-gray-500 text-white px-6 py-2 rounded-lg"
                >
                  Anterior
                </motion.button>
              )}

              <motion.button
                type={currentStep === totalSteps - 1 ? 'submit' : 'button'}
                onClick={currentStep < totalSteps - 1 ? handleNext : null}
                whileHover={{ scale: 1.05 }}
                className="bg-blue-900 text-white px-6 py-2 rounded-lg ml-auto"
              >
                {currentStep === totalSteps - 1 ? 'Enviar Solicitud' : 'Siguiente'}
              </motion.button>
            </div>
          </motion.div>
        </AnimatePresence>
      </form>
    </div>
  );
}
